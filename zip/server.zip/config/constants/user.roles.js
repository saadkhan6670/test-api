module.exports = {
  user: 'user',
  guest: 'guest',
  anonymous: 'anonymous'
};
