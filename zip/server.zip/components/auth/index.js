'use strict';

import social from './social';
import local from './local';

module.exports = {
  social: social,

  local: local
};
