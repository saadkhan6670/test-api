/**
 *
 */
import ms from 'ms';
import { getOAuth2Data } from './../oauth2/oauth.info';

module.exports = function() {
  //const { expires_in } = getOAuth2Data();
  //var interval = (expires_in * 1000) - ms('1h'); // token expire time - 1 hour in ms

  //setInterval(() => getOAuth2Data(), interval);
};
